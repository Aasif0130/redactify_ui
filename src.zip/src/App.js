import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Signin from '../src/components/Signin'; // Import the SignInPage component
import TypeOfMigration from './components/TypeOfMigration';
import Projects from './components/project';
import Connection from './components/Connection';
import NavTabs from './components/NavTabs';
import Scope from './components/Scope';
import VQLBuilder from './components/VQLBuilder';
// index.js or App.js
import './App.css'; // or the path to your global CSS file
import Loader from './components/Loader';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Signin />} />
        <Route path="/choose" element={<TypeOfMigration/>}/>
        <Route path="/projects" element={<Projects/>}/>
        <Route path="/connection" element={<Connection/>}/>
        <Route path="/navtabs" element={<NavTabs/>}/>
        <Route path="/scope" element={<Scope/>}/>
        <Route path="/vqlbuilder" element={<VQLBuilder/>}/>
        <Route path="/loader" element={<Loader/>}/>

      </Routes>
    </Router>
  );
}

export default App;
