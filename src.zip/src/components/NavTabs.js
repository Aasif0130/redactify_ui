import React, { useState } from 'react';
import { ReactComponent as ConnectionIcon } from '../assets/svg/connection.svg';
import { ReactComponent as ScopeIcon } from '../assets/svg/scope.svg';
import { ReactComponent as MapperIcon } from '../assets/svg/mapper.svg';
import { ReactComponent as VqlBuilderIcon } from '../assets/svg/vqlbuilder.svg';
import { ReactComponent as TriggersIcon } from '../assets/svg/triggers.svg';
import { ReactComponent as AttachmentsIcon } from '../assets/svg/attachements.svg';
import { ReactComponent as AuditTrailIcon } from '../assets/svg/audittrial.svg';
import { ReactComponent as DataMigrationIcon } from '../assets/svg/datamigration.svg';
import { ReactComponent as LogsIcon } from '../assets/svg/logs.svg';
import '../assets/styles/NavTabs.css';

const navItems = [
  { name: 'Connection', Icon: ConnectionIcon },
  { name: 'Scope', Icon: ScopeIcon },
  { name: 'Mapper', Icon: MapperIcon },
  { name: 'VQL Builder', Icon: VqlBuilderIcon },
  { name: 'Triggers', Icon: TriggersIcon },
  { name: 'Attachments', Icon: AttachmentsIcon },
  { name: 'Audit Trail', Icon: AuditTrailIcon },
  { name: 'Data Migration', Icon: DataMigrationIcon },
  { name: 'Logs', Icon: LogsIcon },
];

const NavTabs = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const handleTabClick = (index) => {
    setActiveIndex(index);
  };

  return (
    <div className="nav-tabs">
      {navItems.map((item, index) => (
        <div
          key={index}
          className={`nav-item ${activeIndex === index ? 'active' : ''}`}
          onClick={() => handleTabClick(index)}
        >
          <span>{item.name}</span>
          <item.Icon />
        </div>
      ))}
    </div>
  );
};

export default NavTabs;
