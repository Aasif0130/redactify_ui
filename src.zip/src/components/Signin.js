import React from 'react';
import { Box, Typography, TextField, Button, Grid, InputAdornment, IconButton } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { Person, Lock, Visibility, VisibilityOff } from '@mui/icons-material';
import logo from '../assets/svg/logo.svg';
import image from '../assets/images/laptop.png';
import HeaderSignin from './HeaderSignin';
import { useNavigate } from 'react-router-dom';
import { validateLogin } from '../ServiceManager/SigininService';
import { toast, ToastContainer } from 'react-toastify'; // Import toast and ToastContainer
import 'react-toastify/dist/ReactToastify.css'; // Import Toastify CSS

const theme = createTheme({
  palette: {
    primary: {
      main: '#225DFF',
    },
    text: {
      primary: '#000000',
    },
    success: {
      main: '#4CAF50',
    },
    error: {
      main: '#F44336',
    },
  },
  components: {
    MuiTextField: {
      styleOverrides: {
        root: {
          borderRadius: '25px',
          backgroundColor: '#ffffff',
          '& .MuiOutlinedInput-root': {
            borderRadius: '25px',
            '&:hover fieldset': {
              borderColor: '#225DFF',
            },
            '&.Mui-focused fieldset': {
              borderColor: '#225DFF',
            },
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: '25px',
          padding: '12px',
          '&:hover': {
            backgroundColor: '#1E4EBD',
          },
        },
      },
    },
  },
});

const SignInPage = () => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [passwordInput, setPasswordInput] = React.useState('');
  const [usernameInput, setUsernameInput] = React.useState('');
  const [buttonColor, setButtonColor] = React.useState('#225DFF'); // Default button color
  const navigate = useNavigate();

  const handleClickShowPassword = () => setShowPassword(!showPassword);

  const handleSignIn = async () => {
    if (!usernameInput || !passwordInput) {
      toast.error('Please enter credentials!', { position: 'top-right' });
      return;
    }

    try {
      const data = await validateLogin(usernameInput, passwordInput);
      localStorage.setItem('owner', usernameInput);
      localStorage.setItem('userId', data.userId);
      setButtonColor('#4CAF50'); // Success color
      toast.success('WELCOME TO AIMIGRATEPRO', { position: 'top-right' });
      setTimeout(() => {
        navigate('/choose');
      }, 1000); // Navigate after 1 second delay
    } catch (err) {
      setButtonColor('#F44336'); // Error color
      toast.error('Please enter correct credentials', { position: 'top-right' });
      setTimeout(() => {
        setButtonColor('#225DFF'); // Reset color after 1 second
      }, 1000);
    }
  };

  // Handle form submit
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent default form submission
    handleSignIn(); // Call sign in function
  };

  return (
    <ThemeProvider theme={theme}>
      <HeaderSignin />
      <Box 
        sx={{
          minHeight: '100vh',
          background: 'linear-gradient(104deg, #7ee3ff 0%, #7ee3ff 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          pl: { xs: 2, sm: 4 },
          pr: { xs: 2, sm: 4 },
        }}
      >
        <Box
          sx={{ 
            width: { xs: '90%', sm: '80%', md: '50%' },
            maxWidth: '400px',
            textAlign: 'left',
            position: 'relative',
            p: 4,
            backgroundColor: '#ffffff',
            borderRadius: '15px',
            boxShadow: 3,
            mr: { xs: '0%', sm: '10%', md: '45%' },
            '&:hover': {
              boxShadow: 6,
            },
          }}
        >
          <Typography variant="h4" sx={{ mb: 2, fontWeight: 'bold', textAlign: 'center' }}>
            Sign In
          </Typography>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2} direction="column">
              <Grid item>
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  id="username"
                  name="username"
                  autoComplete="username"
                  autoFocus
                  placeholder="Username"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Person sx={{ color: '#000', '&:hover': { color: '#225DFF' } }} />
                      </InputAdornment>
                    ),
                    sx: { borderRadius: '25px', backgroundColor: '#f5f5f5' }
                  }}
                  sx={{ 
                    mb: 2,
                    '& .MuiInputLabel-root': {
                      transition: 'all 0.3s ease',
                    },
                    '& .MuiOutlinedInput-root': {
                      transition: 'all 0.3s ease',
                    },
                    '&:hover .MuiInputLabel-root': {
                      color: '#225DFF',
                    },
                  }}
                />
              </Grid>
              <Grid item>
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  autoComplete="current-password"
                  placeholder="Password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Lock sx={{ color: '#000', '&:hover': { color: '#225DFF' } }} />
                      </InputAdornment>
                    ),
                    endAdornment: passwordInput ? (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    ) : null,
                    sx: { borderRadius: '25px', backgroundColor: '#f5f5f5' }
                  }}
                  sx={{ 
                    mb: 3,
                    '& .MuiInputLabel-root': {
                      transition: 'all 0.3s ease',
                    },
                    '& .MuiOutlinedInput-root': {
                      transition: 'all 0.3s ease',
                    },
                    '&:hover .MuiInputLabel-root': {
                      color: '#225DFF',
                    },
                  }}
                />
              </Grid>
              <Grid item>
                <Button
                  type="submit" // Change to submit type
                  fullWidth
                  variant="contained"
                  sx={{ 
                    borderRadius: '25px', 
                    padding: '12px', 
                    fontWeight: 'bold',
                    backgroundColor: buttonColor, // Dynamic button color
                  }}
                >
                  Sign In
                </Button>
              </Grid>
            </Grid>
          </form>
        </Box>
        <img src={image} alt="Laptop" style={{ position: 'absolute', right: 0, height: '100%', width: '38%' }} />
        <img src={logo} alt="Logo" style={{ position: 'absolute', bottom: 20, left: 20, width: '150px' }} />
      </Box>
      <ToastContainer /> {/* Add ToastContainer for displaying toasts */}
    </ThemeProvider>
  );
};

export default SignInPage;
