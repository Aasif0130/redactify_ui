import React, { useState, useEffect } from "react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import {
  Container,
  Paper,
  Grid,
  TextField,
  Button,
  Typography,
  Box,
  MenuItem,
} from "@mui/material";
import Loader from "./Loader";
import Header from "./Header";
import image1 from "../assets/images/connection.png";
import image2 from "../assets/images/image2.png";
import "../assets/styles/Connection.css";
import {
  ConnectionService,
  extractConfig,
  insertSourceObject,
  insertTargetObject,
} from "../ServiceManager/ConnectionService";
import CircularProgress from "@mui/material/CircularProgress";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircle";

const theme = createTheme({
  palette: {
    primary: {
      main: "#1a73e8",
    },
    secondary: {
      main: "#e0e0e0",
    },
    success: {
      main: "#4caf50",
    },
  },
  typography: {
    fontFamily: "Poppins, sans-serif",
  },
});

const Connection = () => {
  const [projectId, setProjectId] = useState("");
  const [sourceConnected, setSourceConnected] = useState(false);
  const [targetConnected, setTargetConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [loaderMessage, setLoaderMessage] = useState("");

  const [extractingConfig, setExtractingConfig] = useState(false); // State for extracting config
  const [extractingData, setExtractingData] = useState(false); // State for starting extraction
  const [extractConfigComplete, setExtractConfigComplete] = useState(false);
  const [startExtractionComplete, setStartExtractionComplete] = useState(false);
  const [connectionError, setConnectionError] = useState({
    source: null,
    target: null,
  });
  const [sourceCredentials, setSourceCredentials] = useState({
    username: "",
    password: "",
  });
  const [targetCredentials, setTargetCredentials] = useState({
    username: "",
    password: "",
  });
  const [sourceMessage, setSourceMessage] = useState("");
  const [targetMessage, setTargetMessage] = useState("");

  useEffect(() => {
    const storedProjectId = localStorage.getItem("projectId");
    if (storedProjectId) {
      setProjectId(storedProjectId);
    } else {
      console.error("Project ID is not set.");
    }

    if (storedProjectId) {
      setSourceConnected(
        localStorage.getItem(`sourceConnected_${storedProjectId}`) === "true"
      );
      setTargetConnected(
        localStorage.getItem(`targetConnected_${storedProjectId}`) === "true"
      );
      setExtractConfigComplete(
        localStorage.getItem(`extractConfigComplete_${storedProjectId}`) ===
          "true"
      );
      setStartExtractionComplete(
        localStorage.getItem(`startExtractionComplete_${storedProjectId}`) ===
          "true"
      );
      setSourceMessage(
        localStorage.getItem(`sourceMessage_${storedProjectId}`) || ""
      );
      setTargetMessage(
        localStorage.getItem(`targetMessage_${storedProjectId}`) || ""
      );
    }
  }, []);

  const handleConnect = async (type) => {
    if (!projectId) return;
    setLoading(true);
    setConnectionError((prev) => ({ ...prev, [type]: null }));
    try {
      if (type === "source") {
        await ConnectionService.connectToSourceVault(
          sourceCredentials.username,
          sourceCredentials.password
        );
        setSourceConnected(true);
        localStorage.setItem(`sourceConnected_${projectId}`, "true");
      } else if (type === "target") {
        await ConnectionService.connectToTargetVault(
          targetCredentials.username,
          targetCredentials.password
        );
        setTargetConnected(true);
        localStorage.setItem(`targetConnected_${projectId}`, "true");
      }
    } catch (error) {
      setConnectionError((prev) => ({ ...prev, [type]: error.message }));
    } finally {
      setLoading(false);
    }
  };

  const handleExtractConfig = async () => {
    if (!projectId) return;
    setExtractingConfig(true);
    setShowLoader(true);
    setLoaderMessage("Extracting configuration...");
    try {
      await extractConfig();
      setExtractConfigComplete(true);
      localStorage.setItem(`extractConfigComplete_${projectId}`, "true");
      setSourceMessage("");
      setTargetMessage("");
    } catch (error) {
      setConnectionError({ source: error.message, target: error.message });
    } finally {
      setExtractingConfig(false);
      setShowLoader(false);
    }
  };

  const handleStartExtraction = async () => {
    if (!projectId) return;
    setExtractingData(true);
    setShowLoader(true);
    setLoaderMessage("Starting extraction...");
    try {
      await insertSourceObject(projectId);
      setSourceMessage("Source inserted successfully");
      localStorage.setItem(`sourceInserted_${projectId}`, "true");

      await insertTargetObject(projectId);
      setTargetMessage("Target inserted successfully");
      localStorage.setItem(`targetInserted_${projectId}`, "true");

      setStartExtractionComplete(true);
      localStorage.setItem(`startExtractionComplete_${projectId}`, "true");
    } catch (error) {
      setConnectionError({ source: error.message, target: error.message });
    } finally {
      setExtractingData(false);
      setShowLoader(false);
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <div className="container">
        <div className="image1" style={{ backgroundImage: `url(${image1})` }}>
          <Header />
          <div className="text-overlay">
            <Typography variant="h1">Vault CTMS Configuration</Typography>
            <Typography variant="body1">
              Provide details for establishing connectivity
            </Typography>
          </div>
        </div>

        <div className="image2" style={{ backgroundImage: `url(${image2})` }}>
          <Container maxWidth="lg">
            <Grid
              container
              spacing={3}
              alignItems="center"
              justifyContent="center"
            >
              <Grid item mr={15} xs={12} sm={5}>
                <Paper
                  elevation={3}
                  style={{
                    borderRadius: "28px",
                    backgroundColor: "#ffffff",
                    padding: "20px",
                    minHeight: "400px",
                  }}
                >
                  <Typography
                    variant="h6"
                    align="center"
                    fontWeight="bold"
                    style={{ fontSize: "24px" }}
                  >
                    Source
                  </Typography>

                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      Source
                    </Typography>
                    <TextField
                      select
                      fullWidth
                      disabled
                      value="Veeva Vault"
                      InputProps={{
                        readOnly: true,
                        style: {
                          background:
                            "linear-gradient(180deg, #2379FF 10.89%, #154999 100.4%)",
                          borderRadius: "9px",
                          border: "1px solid #ADA7A7",
                          color: "#ffffff",
                          fontWeight: "bold",
                        },
                      }}
                      InputLabelProps={{
                        style: {
                          color: "#ffffff",
                        },
                      }}
                    >
                      <MenuItem
                        value="Veeva Vault"
                        style={{ color: "#ffffff", fontWeight: "bold" }}
                      >
                        Veeva Vault
                      </MenuItem>
                    </TextField>
                  </Box>
                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      DNS
                    </Typography>
                    <TextField fullWidth />
                  </Box>
                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      User Name
                    </Typography>
                    <TextField
                      fullWidth
                      value={sourceCredentials.username}
                      onChange={(e) =>
                        setSourceCredentials({
                          ...sourceCredentials,
                          username: e.target.value,
                        })
                      }
                      disabled={sourceConnected}
                    />
                  </Box>
                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      Password
                    </Typography>
                    <TextField
                      type="password"
                      fullWidth
                      value={sourceCredentials.password}
                      onChange={(e) =>
                        setSourceCredentials({
                          ...sourceCredentials,
                          password: e.target.value,
                        })
                      }
                      disabled={sourceConnected}
                    />
                  </Box>
                  <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={() => handleConnect("source")}
                    disabled={sourceConnected || loading}
                    style={{
                      borderRadius: "20px",
                      background:
                        "linear-gradient(132deg, #2378FD 36.58%, #1956B4 81.31%)",
                      boxShadow: "0px 4px 19px 0px rgba(119, 147, 65, 0.30)",
                    }}
                  >
                    {loading ? (
                      <CircularProgress size={24} color="inherit" />
                    ) : sourceConnected ? (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          color: "white",
                        }}
                      >
                        <span style={{ marginRight: 8 }}>Connected</span>
                        <CheckCircleOutlineIcon style={{ color: "white" }} />
                      </div>
                    ) : (
                      "Connect"
                    )}
                  </Button>
                  {sourceConnected && (
                    <Typography color="success.main" align="center">
                      Source Vault Connected Successfully
                    </Typography>
                  )}
                  {connectionError.source && (
                    <Typography color="error.main" align="center">
                      {connectionError.source}
                    </Typography>
                  )}
                  {sourceMessage && (
                    <Typography color="success.main" align="center">
                      {sourceMessage}
                    </Typography>
                  )}
                </Paper>
              </Grid>
              <Grid item ml={5} xs={12} sm={5}>
                <Paper
                  elevation={3}
                  style={{
                    borderRadius: "28px",
                    backgroundColor: "#e5ecf6",
                    padding: "20px",
                    minHeight: "400px",
                  }}
                >
                  <Typography
                    variant="h6"
                    align="center"
                    fontWeight="bold"
                    style={{ fontSize: "24px" }}
                  >
                    Target
                  </Typography>

                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      Target
                    </Typography>
                    <TextField
                      select
                      fullWidth
                      disabled
                      value="Veeva Vault"
                      InputProps={{
                        readOnly: true,
                        style: {
                          background:
                            "linear-gradient(180deg, #2379FF 10.89%, #154999 100.4%)",
                          borderRadius: "9px",
                          border: "1px solid #ADA7A7",
                          color: "#ffffff",
                          fontWeight: "bold",
                        },
                      }}
                      InputLabelProps={{
                        style: {
                          color: "#ffffff",
                        },
                      }}
                    >
                      <MenuItem
                        value="Veeva Vault"
                        style={{ color: "#ffffff", fontWeight: "bold" }}
                      >
                        Veeva Vault
                      </MenuItem>
                    </TextField>
                  </Box>
                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      DNS
                    </Typography>
                    <TextField fullWidth />
                  </Box>
                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      User Name
                    </Typography>
                    <TextField
                      fullWidth
                      value={targetCredentials.username}
                      onChange={(e) =>
                        setTargetCredentials({
                          ...targetCredentials,
                          username: e.target.value,
                        })
                      }
                      disabled={targetConnected}
                    />
                  </Box>
                  <Box style={{ marginBottom: "16px" }}>
                    <Typography variant="body2" fontWeight="bold">
                      Password
                    </Typography>
                    <TextField
                      type="password"
                      fullWidth
                      value={targetCredentials.password}
                      onChange={(e) =>
                        setTargetCredentials({
                          ...targetCredentials,
                          password: e.target.value,
                        })
                      }
                      disabled={targetConnected}
                    />
                  </Box>
                  <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={() => handleConnect("target")}
                    disabled={!sourceConnected || targetConnected || loading}
                    style={{
                      borderRadius: "20px",
                      background:
                        "linear-gradient(132deg, #2378FD 36.58%, #1956B4 81.31%)",
                      boxShadow: "0px 4px 19px 0px rgba(119, 147, 65, 0.30)",
                    }}
                  >
                    {loading ? (
                      <CircularProgress size={24} color="inherit" />
                    ) : targetConnected ? (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          color: "white",
                        }}
                      >
                        <span style={{ marginRight: 8 }}>Connected</span>
                        <CheckCircleOutlineIcon style={{ color: "white" }} />
                      </div>
                    ) : (
                      "Connect"
                    )}
                  </Button>
                  {targetConnected && (
                    <Typography color="success.main" align="center">
                      Target Vault Connected Successfully
                    </Typography>
                  )}
                  {connectionError.target && (
                    <Typography color="error.main" align="center">
                      {connectionError.target}
                    </Typography>
                  )}
                  {targetMessage && (
                    <Typography color="success.main" align="center">
                      {targetMessage}
                    </Typography>
                  )}
                </Paper>
              </Grid>
              <Grid
                item
                xs={12}
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  padding: "16px",
                }}
              >
                <Button
                  variant="contained"
                  color="primary"
                  disabled={
                    !sourceConnected ||
                    !targetConnected ||
                    extractingConfig ||
                    extractConfigComplete
                  }
                  style={{
                    borderRadius: "20px",
                    background:
                      "linear-gradient(132deg, #2378FD 36.58%, #1956B4 81.31%)",
                    boxShadow: "0px 4px 19px 0px rgba(119, 147, 65, 0.30)",
                    margin: "8px",
                  }}
                  onClick={handleExtractConfig}
                >
                  {extractingConfig ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : extractConfigComplete ? (
                    <>
                      <span style={{ color: "white", marginRight: 8 }}>
                        Extraction Completed
                      </span>
                      <CheckCircleOutlineIcon style={{ color: "white" }} />
                    </>
                  ) : (
                    "Extract Configuration"
                  )}
                </Button>

                <Button
                  variant="contained"
                  color="secondary"
                  disabled={
                    !sourceConnected ||
                    !targetConnected ||
                    extractingData ||
                    startExtractionComplete
                  }
                  style={{
                    borderRadius: "20px",
                    background:
                      "linear-gradient(132deg, #2378FD 36.58%, #1956B4 81.31%)",
                    boxShadow: "0px 4px 19px 0px rgba(119, 147, 65, 0.30)",
                    margin: "8px",
                  }}
                  onClick={handleStartExtraction}
                >
                  {extractingData ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : startExtractionComplete ? (
                    <>
                      <span style={{ color: "white", marginRight: 8 }}>
                        Extracted
                      </span>
                      <CheckCircleOutlineIcon style={{ color: "white" }} />
                    </>
                  ) : (
                    <span style={{ color: "white", marginRight: 8 }}>
                      Start Extraction
                    </span>
                  )}
                </Button>

                <Button
                  variant="contained"
                  disabled={
                    !sourceConnected ||
                    !targetConnected ||
                    extractingData ||
                    !startExtractionComplete
                  }
                  style={{
                    borderRadius: "20px",
                    background:
                      "linear-gradient(132deg, #2378FD 36.58%, #1956B4 81.31%)",
                    boxShadow: "0px 4px 19px 0px rgba(119, 147, 65, 0.30)",
                    margin: "8px",
                  }}
                >
                  Next
                </Button>
              </Grid>

              {showLoader && (
                <div className="loader-overlay">
                  <div className="loader-box">
                    <Loader message={loaderMessage} />
                  </div>
                </div>
              )}
            </Grid>
          </Container>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default Connection;
