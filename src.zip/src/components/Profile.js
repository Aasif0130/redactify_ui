// src/components/Profile.js
import React from 'react';
import { Box, Typography } from '@mui/material';
import { styled } from '@mui/system';
import { AccountCircle, Dashboard, Settings } from '@mui/icons-material'; // MUI icons

// Styled profile container with gradient background
const ProfileContainer = styled(Box)(({ theme }) => ({
  background: 'linear-gradient(135deg, #003366 0%, #0099ff 100%)', // Dark blue to light blue gradient
  color: '#FFFFFF', // White text color
  padding: '10px', // Reduced padding
  borderRadius: '10px', // Slightly reduced border radius
  boxShadow: '0 3px 8px rgba(0, 0, 0, 0.3)', // Slightly reduced shadow
  width: '200px', // Reduced width
  textAlign: 'center', // Center the text
}));

const WelcomeText = styled(Typography)(({ theme }) => ({
  fontWeight: 'bold',
  marginBottom: '5px', // Reduced margin
  fontSize: '1.25rem', // Smaller font size
  lineHeight: '1.3', // Slightly improved line height
}));

const DescriptionText = styled(Typography)(({ theme }) => ({
  fontSize: '0.75rem', // Smaller font size
  marginBottom: '10px', // Reduced margin for spacing
}));

const IconContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-around',
  marginBottom: '10px', // Reduced space between icons and text
}));

const Icon = styled('div')({
  fontSize: '20px', // Smaller icon size
  color: '#FFFFFF', // White icon color
});

const Typewriter = styled(Typography)(({ theme }) => ({
  display: 'inline-block',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  borderRight: '1px solid #FFFFFF', // Reduced cursor effect size
  animation: 'typing 1.5s steps(30, end), blink-caret .75s step-end infinite', // Adjusted animation steps
  fontSize: '1.5rem', // Smaller font size
  fontWeight: 'bold',
  marginBottom: '5px', // Reduced margin
  '@keyframes typing': {
    from: { width: 0 },
    to: { width: '100%' },
  },
  '@keyframes blink-caret': {
    from: { borderColor: 'transparent' },
    to: { borderColor: 'transparent' },
  },
}));

const Profile = ({ name }) => (
  <ProfileContainer>
    <Typewriter variant="h6">Hey {name}!</Typewriter>
    <DescriptionText variant="body2">
      Welcome to AIMIGRATEPRO.
    </DescriptionText>
  </ProfileContainer>
);

export default Profile;
