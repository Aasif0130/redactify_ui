import React, { useState, useEffect } from "react";
import "../assets/styles/Projects.css"; // Adjust the path if necessary
import {
  Container,
  Paper,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  InputAdornment,
  FormControl,
  ThemeProvider,
  createTheme,
  Pagination,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  Select,
  IconButton,
  Chip,
  Autocomplete,
} from "@mui/material";
import {
  Add as AddIcon,
  Search as SearchIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  AddCircle,
} from "@mui/icons-material";
import Tooltip from "@mui/material/Tooltip";

// Import images
import image1 from "../assets/images/image1.png"; // Adjust the path if necessary
import image2 from "../assets/images/image2.png"; // Adjust the path if necessary
import Header from "./Header";
import { ProjectService } from "../ServiceManager/ProjectService";
import { useNavigate } from "react-router-dom";

import veevaURL from "../assets/svg/veeva.svg";

// Define a dark blue theme

const theme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#1976d2", // Blue
    },
    background: {
      default: "#ffffff", // White background
      paper: "#ffffff", // White background for paper components
    },
    text: {
      primary: "#003366", // Dark blue text color
      secondary: "#1976d2", // Blue text color for secondary elements
    },
    divider: "#003366", // Dark blue divider color
    secondary: {
      main: "#B0E0E6", // Light blue color for secondary elements
    },
  },
  typography: {
    fontFamily: "Roboto, Arial, sans-serif",
  },
  components: {
    // Override MUI Dialog styles
    MuiDialog: {
      styleOverrides: {
        paper: {
          backgroundColor: "#ffffff", // White background for the dialog
          color: "#003366", // Dark blue text color
        },
      },
    },
    // Override MUI DialogTitle styles
    MuiDialogTitle: {
      styleOverrides: {
        root: {
          backgroundColor: "#051137", // Dark blue background for the dialog title
          color: "#ffffff", // White text color for the dialog title
          display: "flex",
          alignItems: "center",
          padding: "16px 24px",
        },
      },
    },
    // Override MUI DialogActions styles
    MuiDialogActions: {
      styleOverrides: {
        root: {
          backgroundColor: "#ffffff", // Dark blue background for the dialog footer
          padding: "8px 24px",
        },
      },
    },
    // Override MUI Button styles globally
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          borderRadius: "20px", // Rounded corners
          background: "linear-gradient(90deg, #2378FD 0%, #1956B4 100%)", // Gradient background
          color: "#ffffff", // White text color
          "&:hover": {
            background: "linear-gradient(90deg, #2378FD 0%, #1956B4 100%)", // Keep gradient on hover
          },
        },
        // Apply specific styles for table heading buttons
        tableHeadingButton: {
          backgroundColor: "transparent", // Transparent background
          color: "#050e32", // Specific color for table heading buttons
          fontWeight: "bold",
          fontSize: "16px",
          textTransform: "none",
          border: "none",
          "&:hover": {
            backgroundColor: "transparent", // Keep transparent on hover
          },
        },
      },
    },
    // Override MUI TableContainer styles
    MuiTableContainer: {
      styleOverrides: {
        root: {
          backgroundColor: "#ffffff", // White background for the table container
        },
      },
    },
    // Override MUI Table styles
    MuiTable: {
      styleOverrides: {
        root: {
          backgroundColor: "#ffffff", // White background for the table
        },
      },
    },
    // Override MUI TableHead styles
    MuiTableHead: {
      styleOverrides: {
        root: {
          backgroundColor: "#051137", // Dark navy blue for table heading
          color: "#ffffff", // White text color for table headings
        },
      },
    },
    // Override MUI TableCell styles
    MuiTableCell: {
      styleOverrides: {
        root: {
          color: "#003366", // Dark blue text color for table cells
        },
      },
    },
    // Override MUI Pagination styles
    MuiPagination: {
      styleOverrides: {
        root: {
          color: "#1976d2", // Blue text color for pagination
        },
        ul: {
          "& .MuiPaginationItem-root": {
            color: "#1976d2", // Blue text color for pagination items
            "&.Mui-selected": {
              backgroundColor: "#1976d2", // Blue background when selected
              color: "#ffffff", // White text color when selected
            },
          },
        },
        // Make sure pagination text is also blue
        "& .MuiPaginationItem-page": {
          color: "#1976d2", // Blue text color for pagination numbers
        },
        "& .MuiPaginationItem-ellipsis": {
          color: "#1976d2", // Blue text color for ellipsis
        },
      },
    },
    // Override MUI TextField styles
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            "& fieldset": {
              borderColor: "#003366", // Dark blue border for text fields
            },
            "&:hover fieldset": {
              borderColor: "#003366", // Dark blue border on hover
            },
            "&.Mui-focused fieldset": {
              borderColor: "#003366", // Dark blue border when focused
            },
          },
          "& .MuiInputBase-input": {
            color: "#003366", // Dark blue text color
          },
        },
      },
    },
    // Override MUI Select styles
    MuiSelect: {
      styleOverrides: {
        root: {
          color: "#003366", // Dark blue text color
        },
        select: {
          color: "#003366", // Dark blue text color for the selected item
        },
        icon: {
          color: "#003366", // Dark blue color for the dropdown icon
        },
      },
    },
    // Override MUI MenuItem styles
    MuiMenuItem: {
      styleOverrides: {
        root: {
          color: "#003366", // Dark blue text color for menu items
          "&.Mui-selected": {
            backgroundColor: "#e0e0e0", // Light grey background for selected items
            color: "#003366", // Dark blue text color for selected items
          },
        },
      },
    },
    // Override MUI Chip styles
    MuiChip: {
      styleOverrides: {
        root: {
          borderColor: "#003366", // Dark blue border for chips
          color: "#003366", // Dark blue text color for chips
        },
      },
    },
  },
});

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [filteredProjectUserOptions, setFilteredProjectUserOptions] = useState(
    []
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [sortConfig, setSortConfig] = useState({ key: "", direction: "asc" });
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [openCreateDialog, setOpenCreateDialog] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [userName, setUserName] = useState("");
  const [selectedProjectUsers, setSelectedProjectUsers] = useState([]);
  const [selectedSource, setSelectedSource] = useState("");
  const [selectedTarget, setSelectedTarget] = useState("");
  const [selectedProjectType, setSelectedProjectType] = useState("");
  const [projectNameError, setProjectNameError] = useState(false);
  const [sourceError, setSourceError] = useState(false);
  const [targetError, setTargetError] = useState(false);
  const [projectTypeError, setProjectTypeError] = useState(false);
  const [projectOwnersError, setProjectOwnersError] = useState(false);
  const [projectTypeOptions, setProjectTypeOptions] = useState([]);
  const [projectUserOptions, setProjectUserOptions] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    // Retrieve the owner name from local storage
    const ownerName = localStorage.getItem("owner");

    // Filter out the owner from the options
    const filteredOptions = projectUserOptions.filter(
      (option) => option.label !== ownerName
    );

    setFilteredProjectUserOptions(filteredOptions);
  }, [projectUserOptions]); // Re-run the effect when projectUserOptions change

  useEffect(() => {
    fetchProjects();
    fetchProjectTypes();
    fetchProjectUsers();
  }, []);

  useEffect(() => {
    const storedOwner = localStorage.getItem("owner");
    if (storedOwner) {
      setUserName(storedOwner);
    }
  }, []);

  // Filter and sort projects
  const fetchProjectTypes = () => {
    ProjectService.fetchProjectTypes()
      .then((response) => {
        setProjectTypeOptions(response.data);
      })
      .catch((error) => {
        console.error("Error fetching project types:", error);
      });
  };
  const fetchProjectUsers = async () => {
    try {
      const response = await ProjectService.fetchProjectUsers();
      const ownerName = localStorage.getItem("owner");
      const mappedUsers = response.data
        .filter((user) => user.userName !== ownerName) // Exclude owner
        .map((user) => ({
          value: user.userId,
          label: user.userName,
        }));
      setFilteredProjectUserOptions(mappedUsers);
    } catch (error) {
      console.error("Error fetching project users:", error);
    }
  };
  const fetchProjects = () => {
    ProjectService.fetchProjects()
      .then((response) => {
        const projectsWithDefaults = response.data.map((project) => ({
          ...project,
          source: <img src={veevaURL} alt="Veeva Vault" />, // Use SVG URL
          target: <img src={veevaURL} alt="Veeva Vault" />, // Use SVG URL
        }));
        setProjects(projectsWithDefaults);
        console.log("projects", projectsWithDefaults);
        console.log("response.data", response.data);
      })
      .catch((error) => {
        console.error("Error fetching project types:", error);
      });
  };

  const filteredAndSortedProjects = projects
    .filter((project) => {
      // Logging to debug

      const projectName = project.projectName || "";
      const projectType = project.projectType || "";
      const projectStatus = project.projectStatus || "";

      return (
        projectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        projectType.toLowerCase().includes(searchQuery.toLowerCase()) ||
        projectStatus.toLowerCase().includes(searchQuery.toLowerCase())
      );
    })
    .sort((a, b) => {
      const aKey = a[sortConfig.key] || "";
      const bKey = b[sortConfig.key] || "";
      return sortConfig.direction === "asc"
        ? aKey.localeCompare(bKey)
        : bKey.localeCompare(aKey);
    });

  const paginatedProjects = filteredAndSortedProjects.slice(
    (page - 1) * rowsPerPage,
    page * rowsPerPage
  );

  const ownerName = localStorage.getItem("owner");
  const userId = localStorage.getItem("userId");
  if (!ownerName || !userId) {
    console.error("Owner name or User ID not found in local storage");
    return;
  }
  const handleSearch = (event) => setSearchQuery(event.target.value);
  const handleSort = (key) => {
    setSortConfig((prevConfig) => ({
      key,
      direction:
        prevConfig.key === key && prevConfig.direction === "asc"
          ? "desc"
          : "asc",
    }));
  };
  const handleChangePage = (event, value) => setPage(value);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(1);
  };
  const handleOpenCreateDialog = () => setOpenCreateDialog(true);
  const handleCloseCreateDialog = () => {
    setOpenCreateDialog(false);
    // Reset error states on close
    setProjectNameError(false);
    setProjectOwnersError(false);

    setProjectTypeError(false);
    setSourceError(false);
    setTargetError(false);
  };
  const handleCreateProject = async () => {
    // Reset errors
    setProjectNameError(false);
    setProjectOwnersError(false);
    setProjectTypeError(false);
    setSourceError(false);
    setTargetError(false);

    let hasError = false;

    // Validate Project Name
    if (projectName.trim() === "") {
      setProjectNameError(true);
      hasError = true;
    }

    // Validate Project Type
    if (selectedProjectType.trim() === "") {
      setProjectTypeError(true);
      hasError = true;
    }

    // Validate Source
    if (selectedSource.trim() === "") {
      setSourceError(true);
      hasError = true;
    }

    // Validate Target
    if (selectedTarget.trim() === "") {
      setTargetError(true);
      hasError = true;
    }

    // If there's an error, exit the function
    if (hasError) return;

    // Fetch username and userId from local storage
    const ownerName = localStorage.getItem("owner");
    const userId = localStorage.getItem("userId"); // Assuming userId is stored in localStorage

    if (!ownerName || !userId) {
      console.error("Owner name or User ID not found in local storage");
      return;
    }

    // Proceed to create the project
    try {
      const projectData = {
        userId: parseInt(userId, 10), // Use fetched userId here
        userName: ownerName, // Use fetched username here
        projectName: projectName,
        isPowerUser: true,
        isSecondaryUser: false,
        isActive: true,
        createdBy: ownerName, // Optional
        updatedBy: ownerName, // Optional
        projectTypeId: selectedProjectType, // Ensure this is correct
        projectTypeName:
          projectTypeOptions.find(
            (option) => option.projectTypeId === selectedProjectType
          )?.projectTypeName || "",
        projectUsers: selectedProjectUsers.map((user) => user.value).join(","),
        source: selectedSource,
        target: selectedTarget,
      };

      const response = await ProjectService.createProject(projectData);
      console.log("Project(s) created successfully:", response.data);
      handleCloseCreateDialog();

      // Reset form fields
      setProjectName("");
      setSelectedProjectUsers([]);
      setSelectedSource("");
      setSelectedTarget("");
      setSelectedProjectType("");

      // Fetch updated list of projects and users
      fetchProjects();
      await fetchProjectUsers(); // Ensure to fetch updated list of users
    } catch (error) {
      console.error("Error creating project(s):", error);
    }
  };
  const handleClickProjectName = (projectName, projectId) => {
    // Find the clicked project based on projectId
    const clickedProject = projects.find(
      (project) => project.projectId === projectId
    );

    if (clickedProject) {
      // Extract and store the executionId from the clicked project
      const { executionId } = clickedProject;
      localStorage.setItem("executionId", executionId);
      localStorage.setItem("projectId", projectId);
      console.log("ExecutionId", executionId, projectId);
    }

    // Store project name and ID in local storage
    localStorage.setItem("selectedProjectName", projectName);
    localStorage.setItem("selectedProjectId", projectId);

    console.log("localStorage", projectName, projectId);

    // Navigate to /connection route
    navigate("/connection");
  };

  return (
    <ThemeProvider theme={theme}>
      <div className="container">
        <div className="image1" style={{ backgroundImage: `url(${image1})` }}>
          <Header />
          <div className="text-overlay">
            <h1>List of Projects</h1>
            <p>Data migration / Document migration</p>
          </div>
        </div>

        <div className="image2" style={{ backgroundImage: `url(${image2})` }}>
          <div className="table-container">
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                minHeight: "53.7vh",
                backgroundColor: "#ffffff",
                padding: "20px",
                borderRadius: "12px",
              }}
            >
              <Container maxWidth="xl">
                <Box
                  mt={1}
                  mb={6}
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <Typography variant="h5" color="#1988b0">
                    Projects
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <TextField
                      placeholder="Search using Project Name"
                      variant="outlined"
                      value={searchQuery}
                      onChange={handleSearch}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SearchIcon color="primary" />
                          </InputAdornment>
                        ),
                        sx: {
                          height: "42px",
                          padding: "9px 12px",
                          borderRadius: "8px",
                          border: "1px solid #1976d2",
                          background: "#fffff",
                          color: "black",
                        },
                      }}
                    />
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<AddIcon />}
                      onClick={handleOpenCreateDialog}
                      sx={{ ml: 2 }}
                    >
                      Create Project
                    </Button>
                  </Box>
                </Box>
                <Paper
                  elevation={0}
                  sx={{
                    height: "auto",
                    backgroundColor: "#ffffff",
                  }}
                >
                  <TableContainer
                    component={Paper}
                    className="custom-scrollbar"
                    sx={{
                      marginTop: "20px",
                      backgroundColor: "#1d8fb7",
                      maxHeight: "300px",
                      width: "1200px",
                      overflowY: "auto",
                      boxShadow: "none", // Remove Paper shadow if any
                      border: "none", // Remove any border from Paper
                    }}
                  >
                    <Table
                      stickyHeader
                      sx={{
                        borderCollapse: "collapse",
                        border: "none", // Remove border from Table
                        "& td, & th": {
                          border: "none", // Remove border from TableCells
                          textAlign: "left", // Align text to the left
                        },
                      }}
                    >
                      <TableHead sx={{ borderBottom: "none" }}>
                        <TableRow>
                          <TableCell
                            sx={{
                              color: "#ffffff",
                              borderBottom: "none",
                            }}
                          >
                            <button
                              onClick={() => handleSort("projectName")}
                              className="custom-table-button"
                            >
                              Project Name
                              {sortConfig.key === "projectName" &&
                                (sortConfig.direction === "asc" ? (
                                  <ArrowUpwardIcon color="primary" />
                                ) : (
                                  <ArrowDownwardIcon color="primary" />
                                ))}
                            </button>
                          </TableCell>
                          <TableCell
                            sx={{
                              color: "#050e32",
                              borderBottom: "none",
                            }}
                          >
                            <button
                              onClick={() => handleSort("projectType")}
                              className="custom-table-button"
                            >
                              Project Type
                              {sortConfig.key === "projectType" &&
                                (sortConfig.direction === "asc" ? (
                                  <ArrowUpwardIcon color="primary" />
                                ) : (
                                  <ArrowDownwardIcon color="primary" />
                                ))}
                            </button>
                          </TableCell>
                          <TableCell
                            sx={{
                              color: "#050e32",
                              borderBottom: "none",
                            }}
                          >
                            <button className="custom-table-button">
                              Source
                            </button>
                          </TableCell>
                          <TableCell
                            sx={{
                              color: "#050e32",
                              borderBottom: "none",
                            }}
                          >
                            <button className="custom-table-button">
                              Target
                            </button>
                          </TableCell>
                          <TableCell
                            sx={{
                              color: "#050e32",
                              borderBottom: "none",
                            }}
                          >
                            <button
                              onClick={() => handleSort("projectStatus")}
                              className="custom-table-button"
                            >
                              Project Status
                              {sortConfig.key === "projectStatus" &&
                                (sortConfig.direction === "asc" ? (
                                  <ArrowUpwardIcon color="primary" />
                                ) : (
                                  <ArrowDownwardIcon color="primary" />
                                ))}
                            </button>
                          </TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {paginatedProjects.map((project) => {
                          // Determine if tooltip should be applied based on text length
                          const shouldApplyTooltip =
                            project.projectName.length > 30;
                          const truncatedName =
                            project.projectName.length > 30
                              ? `${project.projectName.slice(0, 30)}...`
                              : project.projectName;

                          return (
                            <TableRow
                              key={project.id}
                              sx={{
                                cursor: "default", // Remove cursor pointer for rows
                                borderTop: "1px solid #ddd", // Line above the row
                                borderBottom: "1px solid #ddd", // Line below the row
                                "&:last-child": {
                                  borderBottom: "none", // Remove bottom border from the last row
                                },
                              }}
                            >
                              <TableCell
                                onClick={() =>
                                  handleClickProjectName(
                                    project.projectName,
                                    project.projectId
                                  )
                                }
                                sx={{
                                  fontSize: "0.9em",
                                  fontWeight: "bold",
                                  textDecoration: "none",
                                  position: "relative", // Required for tooltip positioning
                                  maxWidth: "300px", // Adjust as needed to fit your table layout
                                  overflow: "hidden", // Hide overflowing text
                                  whiteSpace: "nowrap", // Prevent text wrapping
                                  textOverflow: "ellipsis", // Add ellipsis when text is too long
                                  "&:hover": {
                                    textDecoration: "underline",
                                    fontSize: "1.1em",
                                    fontWeight: "bold",
                                  },
                                }}
                              >
                                {shouldApplyTooltip ? (
                                  <Tooltip
                                    title={project.projectName}
                                    arrow
                                    placement="top"
                                    sx={{
                                      maxWidth: "none", // Ensure tooltip does not cut off long text
                                    }}
                                  >
                                    <Typography
                                      sx={{
                                        display: "inline",
                                        "&:hover": {
                                          fontWeight: "bold", // Make text bold on hover
                                        },
                                      }}
                                    >
                                      {truncatedName}
                                    </Typography>
                                  </Tooltip>
                                ) : (
                                  <Typography
                                    sx={{
                                      display: "inline",
                                      "&:hover": {
                                        fontWeight: "bold", // Make text bold on hover
                                      },
                                    }}
                                  >
                                    {truncatedName}
                                  </Typography>
                                )}
                              </TableCell>
                              <TableCell>{project.projectTypeName}</TableCell>
                              <TableCell>{project.source}</TableCell>
                              <TableCell>{project.target}</TableCell>
                              <TableCell>
                                <span
                                  style={{
                                    fontWeight: "bold",
                                    color: (() => {
                                      const status =
                                        project.projectStatus.toLowerCase();
                                      switch (status) {
                                        case "extraction completed":
                                          return "#2e7d32"; // Brighter Green
                                        case "yet to start":
                                          return "#616161"; // Brighter Grey
                                        case "in progress":
                                          return "#1976d2"; // Brighter Blue
                                        case "mapping approved":
                                          return "#66bb6a"; // Brighter Light Green
                                        case "migration completed":
                                          return "#7b1fa2"; // Brighter Purple
                                        case "migration failed":
                                          return "#e53935"; // Brighter Red
                                        default:
                                          return "#616161"; // Default grey color if status is unknown
                                      }
                                    })(),
                                  }}
                                >
                                  {project.projectStatus}
                                </span>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>

                  <Box
                    mt={2}
                    display="flex"
                    justifyContent="flex-end"
                    alignItems="center"
                  >
                    <Typography variant="body2" color="white">
                      Showing {(page - 1) * rowsPerPage + 1}-
                      {Math.min(
                        page * rowsPerPage,
                        filteredAndSortedProjects.length
                      )}{" "}
                      of {filteredAndSortedProjects.length}
                    </Typography>
                    <Pagination
                      count={Math.ceil(
                        filteredAndSortedProjects.length / rowsPerPage
                      )}
                      page={page}
                      onChange={handleChangePage}
                      color="primary"
                    />
                    <FormControl variant="outlined" size="small">
                      <Select
                        value={rowsPerPage}
                        onChange={handleChangeRowsPerPage}
                        sx={{
                          height: "42px",
                          borderRadius: "8px",
                          border: "2px solid #192446",
                          background: "#ffffff",
                          color: "blue",
                        }}
                      >
                        {[10, 25, 50].map((pageSize) => (
                          <MenuItem key={pageSize} value={pageSize}>
                            {pageSize} rows
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>
                </Paper>
              </Container>
            </Box>

            {/* Create Project Dialog */}

            <Dialog
              open={openCreateDialog}
              onClose={handleCloseCreateDialog}
              maxWidth="md"
              fullWidth
            >
              <DialogTitle className="custom-dialog-title">
                <AddCircle className="custom-dialog-icon" />
                Create Project
              </DialogTitle>
              <DialogContent dividers className="custom-dialog-content">
                <Typography variant="h6" className="custom-dialog-label">
                  Project Name *
                </Typography>
                <TextField
                  autoFocus
                  margin="dense"
                  id="projectName"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  type="text"
                  fullWidth
                  variant="outlined"
                  required
                  error={projectNameError}
                  helperText={
                    projectNameError ? "Project Name is required" : ""
                  }
                  inputProps={{ maxLength: 100 }}
                  className="custom-textfield"
                />
                <Typography variant="h6" className="custom-dialog-label">
                  Project Owners *
                </Typography>
                <TextField
                  margin="dense"
                  id="userName"
                  value={userName}
                  type="text"
                  fullWidth
                  variant="outlined"
                  InputProps={{ readOnly: true }}
                  className="custom-textfield-readonly"
                />
                <Typography variant="h6" className="custom-dialog-label">
                  Project Users
                </Typography>
                <Autocomplete
                  multiple
                  options={filteredProjectUserOptions}
                  getOptionLabel={(option) => option.label}
                  value={selectedProjectUsers}
                  onChange={(event, newValue) =>
                    setSelectedProjectUsers(newValue)
                  }
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => (
                      <Chip
                        variant="outlined"
                        label={option.label}
                        {...getTagProps({ index })}
                        key={index}
                        className="custom-chip"
                      />
                    ))
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      variant="outlined"
                      margin="normal"
                      className="custom-textfield"
                    />
                  )}
                  classes={{
                    inputRoot: "custom-autocomplete",
                  }}
                  disableCloseOnSelect // Prevents the dropdown from closing when an option is selected
                />
                <FormControl fullWidth className="custom-form-control">
                  <Typography variant="h6" className="custom-dialog-label">
                    Source *
                  </Typography>
                  <Select
                    labelId="sourceLabel"
                    id="source"
                    value={selectedSource}
                    onChange={(e) => {
                      setSelectedSource(e.target.value);
                      setSourceError(false); // Reset error on change
                    }}
                    error={sourceError}
                    className="custom-select"
                  >
                    <MenuItem value="Veeva Vault" textAlign="left">
                      <b>Veeva Vault</b>
                    </MenuItem>
                  </Select>
                  {sourceError && (
                    <Typography color="error">Source is required</Typography>
                  )}
                </FormControl>

                <FormControl fullWidth className="custom-form-control">
                  <Typography variant="h6" className="custom-dialog-label">
                    Target *
                  </Typography>
                  <Select
                    labelId="targetLabel"
                    id="target"
                    value={selectedTarget}
                    onChange={(e) => {
                      setSelectedTarget(e.target.value);
                      setTargetError(false); // Reset error on change
                    }}
                    error={targetError}
                    className="custom-select"
                  >
                    <MenuItem value="Veeva Vault" textAlign="left">
                      <b>Veeva Vault</b>
                    </MenuItem>
                  </Select>
                  {targetError && (
                    <Typography color="error">Target is required</Typography>
                  )}
                </FormControl>

                <FormControl fullWidth className="custom-form-control">
                  <Typography variant="h6" className="custom-dialog-label">
                    Project Type *
                  </Typography>
                  <TextField
                    margin="dense"
                    id="projectTypeId"
                    value={selectedProjectType}
                    onChange={(e) => setSelectedProjectType(e.target.value)}
                    select
                    fullWidth
                    variant="outlined"
                    required
                    error={projectTypeError}
                    helperText={
                      projectTypeError ? "Project Type is required" : ""
                    }
                    className="custom-textfield"
                  >
                    {projectTypeOptions.map((option) => (
                      <MenuItem
                        key={option.projectTypeId}
                        value={option.projectTypeId}
                      >
                        {option.projectTypeName}
                      </MenuItem>
                    ))}
                  </TextField>
                </FormControl>
              </DialogContent>

              <DialogActions className="custom-dialog-actions">
                <Button
                  onClick={handleCloseCreateDialog}
                  className="custom-cancel-button"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateProject}
                  className="custom-create-button"
                >
                  Create
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        </div>
      </div>
    </ThemeProvider>
  );
};

export default Projects;
