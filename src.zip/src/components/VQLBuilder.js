import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook
import '../assets/styles/VQLBuilder.css'; // Adjust the path if necessary
import {
    Box,
    Typography,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    TextField,
    MenuItem,
    IconButton,
    ThemeProvider,
    createTheme,
    CssBaseline,
    Button,
  } from "@mui/material";
  import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import RemoveCircleOutlineIcon from "@mui/icons-material/RemoveCircleOutline";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { vqlService } from "../ServiceManager/VQLBuilderService";
// Import images
import vqlbuilder from '../assets/images/vqlbuilder.png'; // Adjust the path if necessary
import image2 from '../assets/images/image2.png'; // Adjust the path if necessary

import Header from './Header';

const dummyData = {
    objects: [
      { name: "country__v", idField: "id" },
      { name: "study__v", idField: "id" },
    ],
    fields: [
      "id",
      "name_v",
      "title",
      "description",
      "study_number",
      "first_name",
      "last_name",
      "email",
      "mobile_number",
      "role",
    ],
    conditions: ["=", "!=", ">", "<", ">=", "<="],
  };
  const theme = createTheme({
    palette: {
      primary: {
        main: "#051d45", // Fallback color if gradient isn't applied
      },
      secondary: {
        main: "#E3F2FD", // Light blue for secondary palette
      },
      text: {
        primary: "#000", // Black text for better contrast
      },
    },
    typography: {
      h6: {
        fontWeight: 600,
        fontSize: "1rem",
        color: "#000", // Black text for headers
      },
      body1: {
        fontSize: "0.875rem",
        fontWeight: 400,
        color: "#000", // Black text for body
      },
    },
    components: {
      MuiAccordionDetails: {
        styleOverrides: {
          root: {
            overflowY: "auto",
            transition: "max-height 0.2s ease-out",
            "&.Mui-expanded": {
              maxHeight: 300,
            },
            "&.Mui-collapsed": {
              maxHeight: 50,
            },
          },
        },
      },
      MuiTextField: {
        styleOverrides: {
          root: {
            marginBottom: 8,
            '& .MuiInputBase-root': {
              backgroundColor: '#F5F5F5',
              borderRadius: '8px',
            },
          },
        },
      },
      MuiButton: {
        styleOverrides: {
          root: {
            marginRight: 10,
            borderRadius: 8, // Rounded corners
            background: 'linear-gradient(132deg, #2378FD 36.58%, #1956B4 81.31%)', // Gradient background
            color: '#fff', // White text for buttons
            padding: '10px 20px', // Adjust padding for buttons
            textTransform: 'none', // Prevent text transformation
            boxShadow: 'none', // Remove default shadow
            '&:hover': {
              background: 'linear-gradient(132deg, #1956B4 36.58%, #003366 81.31%)', // Darker gradient on hover
            },
            '&:active': {
              background: 'linear-gradient(132deg, #003366 36.58%, #001a33 81.31%)', // Even darker gradient on active
            },
          },
        },
      },
      MuiOutlinedInput: {
        styleOverrides: {
          root: {
            fontFamily: "monospace",
            fontSize: "1rem",
            fontWeight: "normal",
            color: "#000", // Black text color
            backgroundColor: "#F5F5F5",
            padding: "10px",
            borderRadius: "8px",
            textAlign: "left",
            '&.Mui-focused': {
              borderColor: "#FDB44E",
              boxShadow: "0 0 0 2px rgba(253, 180, 78, 0.2)",
            },
          },
          input: {
            padding: "2px",
          },
        },
      },
    },
  });
  
const VQLBuilder = () => {
    const navigate = useNavigate();
    const [selectedTab, setSelectedTab] = useState(3);
    const [filters, setFilters] = useState([
      { object: "", field: "", condition: "", value: "" },
    ]);
    const [filtersExpanded, setFiltersExpanded] = useState(true);
    const [vqlQuery, setVqlQuery] = useState("");
    const [vqlExpanded, setVqlExpanded] = useState(true);
    const [queryStatuses, setQueryStatuses] = useState([]);
    const [generateVqlDisabled, setGenerateVqlDisabled] = useState(false);
    const [projectId, setProjectId] = useState(null);
  const [userId, setUserId] = useState(null);
  const [executionId, setExecutionId] = useState(null);
  
  useEffect(() => {
    const storedProjectId = localStorage.getItem('projectId');
    
    const storedUserId = localStorage.getItem('userId');
    const storedExecutionId = localStorage.getItem('executionId');
   
    if (storedProjectId) setProjectId(Number(storedProjectId));
    if (storedUserId) setUserId(Number(storedUserId));
    if (storedExecutionId) setExecutionId(Number(storedExecutionId));
    console.log(storedProjectId)
    console.log(storedUserId)
    console.log(storedExecutionId)
  }, []);
  useEffect(() => {
    // Load filters and VQL query from local storage on component mount
    const savedFilters = localStorage.getItem('filters');
    const savedQuery = localStorage.getItem('vqlQuery');
    const isGenerateVqlDisabled = localStorage.getItem('generateVqlDisabled') === 'true';
  
    if (savedFilters) {
      setFilters(JSON.parse(savedFilters));
    }
    
    if (savedQuery) {
      setVqlQuery(savedQuery);
    }
    
    setGenerateVqlDisabled(isGenerateVqlDisabled);
  }, []);
  useEffect(() => {
    // Save filters and VQL query to local storage whenever they change
    localStorage.setItem('filters', JSON.stringify(filters));
    localStorage.setItem('vqlQuery', vqlQuery);
  }, [filters, vqlQuery]);
  useEffect(() => {
    if (filters.every(filter => filter.object && filter.field && filter.condition && filter.value)) {
      const autoGeneratedVql = generateVql();
      setVqlQuery(autoGeneratedVql.join("\n\n"));
    }
  }, [filters]);

  const handleAddFilter = () => {
    setFilters([
      ...filters,
      { object: "", field: "", condition: "", value: "" },
    ]);
  };

  const handleRemoveFilter = (index) => {
    if (filters.length > 1) {
      setFilters(filters.filter((_, i) => i !== index));
    }
  };

  const handleSaveQuery = () => {
    // Save manually edited VQL query to local storage
    localStorage.setItem('vqlQuery', vqlQuery);
    toast.success("VQL Query saved successfully.", toastConfig);
  };

  const handleInputChange = (index, event) => {
    const newFilters = [...filters];
    newFilters[index][event.target.name] = event.target.value;
    setFilters(newFilters);
  };

  const generateVql = () => {
    const objectQueries = {};
    
    dummyData.objects.forEach((object) => {
      objectQueries[object.name] = {
        baseQuery: `SELECT ${object.idField} FROM ${object.name}`,
        conditions: [],
      };
    });
    
    filters.forEach((filter) => {
      if (filter.object && filter.field && filter.condition && filter.value) {
        const formattedValue = filter.value.replace(/,/g, "','");
        const condition = `${filter.field} ${filter.condition} '${formattedValue}'`;
        objectQueries[filter.object].conditions.push(condition);
      }
    });
    
    const queries = [];
    Object.keys(objectQueries).forEach((objectName) => {
      const { baseQuery, conditions } = objectQueries[objectName];
      let query = baseQuery;
      if (conditions.length > 0) {
        query += " WHERE " + conditions.join(" AND ");
      }
      query += ";";
      queries.push(query);
    });
    
    return queries;
  };

  const toastConfig = {
    position: "top-right",
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  };
  const insertVqlDetails = (queries) => {
    if (!Array.isArray(queries) || queries.length === 0) {
      console.error("No queries provided for insertion.");
      toast.error("No queries provided for insertion.", toastConfig);
      return;
    }

    const data = {
      projectId: projectId,
      userId: userId,
      executionId: executionId,
      username: "migratepro_prana@partnersi-prana4life.com",
      password: "Rudhrainfo#5",
      version: "v24.1",
      queryList: queries,
    }

    vqlService.insertDetails(data).then((response)=>{
      console.log("insertVqlDetails API Call Success:", response.data);
      if (response.data && response.data.success) {
        toast.success("Insert VQL Details Success", toastConfig);
      } else if (response.data && response.data.error) {
        toast.error(`Error: ${response.data.error}`, toastConfig);
      } else {
        toast.success("Insert VQL Details Success", toastConfig);
      }
    })
    .catch((error) => {
      console.error("insertVqlDetails API Call Error:", error);
      toast.error("Failed to insert VQL details. Please try again.", toastConfig);
    });
  
   
  };

  const compileQuery = () => {
    setQueryStatuses([]);

    if (!vqlQuery.trim()) {
        toast.error("VQL Query is empty. Please enter a valid query.", toastConfig);
        return;
    }

    const queries = vqlQuery.split("\n").map(query => query.trim()).filter(query => query.length > 0);

    console.log("Generated Queries:", queries);

    if (queries.length === 0) {
        toast.error("No valid queries to compile. Please enter valid queries in the VQL Builder.", toastConfig);
        return;
    }

    const requestData = {
      projectId: projectId,
      userId: userId,
      executionId: executionId,
      username: "migratepro_prana@partnersi-prana4life.com",
      password: "Rudhrainfo#5",
      version: "v24.1",
      queryList: queries,
    };

    console.log("Request Data:", requestData);

    let queriesProcessed = 0;
    let allSuccess = true; // Flag to track if all queries succeed

    const processQuery = (query) => {
        const data = { ...requestData, queryList: [query] };

        vqlService.processDetails(data)
            .then((response) => {
                console.log(`processVqlDetails API Call Success for query: ${query}`, response.data);

                if (Array.isArray(response.data)) {
                    const queryStatus = {
                        query,
                        status: response.data[0].status,
                    };

                    setQueryStatuses((prevStatuses) => [...prevStatuses, queryStatus]);

                    if (queryStatus.status !== "success") {
                        allSuccess = false;
                        toast.error(`Failed to process VQL query: ${query}`, toastConfig);
                    }
                } else {
                    allSuccess = false;
                    toast.error(
                        `Failed to process VQL query due to unexpected response format for query: ${query}`,
                        toastConfig
                    );
                }
            })
            .catch((processError) => {
                console.error(`processVqlDetails API Call Error for query: ${query}`, processError);
                toast.error(`Failed to process VQL query: ${query}. Please try again.`, toastConfig);
                allSuccess = false;
            })
            .finally(() => {
                queriesProcessed++;

                if (queriesProcessed === queries.length) {
                    console.log("All queries processed.");
                    if (allSuccess) {
                        insertVqlDetails(queries);
                    } else {
                        toast.error("One or more queries failed. Insertion not performed.", toastConfig);
                    }
                }
            });
    };

    queries.forEach(processQuery);
};


  const handleNavigateNext = () => {
    navigate("/triggers");
  };

  const handleVqlAccordionChange = () => {
    setVqlExpanded(!vqlExpanded);
  };

  const handleFiltersAccordionChange = () => {
    setFiltersExpanded(!filtersExpanded);
  };

  const handleGenerateVql = () => {
    const generatedVql = generateVql();
    setVqlQuery(generatedVql.join("\n\n"));
    setGenerateVqlDisabled(true);
  };


  return (
    <ThemeProvider theme={theme}>
    <div className="container">
      <div className="vqlbuilder" style={{ backgroundImage: `url(${vqlbuilder})` }}>
        <Header />
        <div className="text-overlay">
          <h1>VQL Builder</h1>
          <p>Establish customised query builder</p>
        </div>
      </div>
      
      <div className="image2" style={{ backgroundImage: `url(${image2})` }}>
      <Box mt={3}>
        <Box display="flex" justifyContent="center" mb={3}>
          <Box width="100%">
            <Accordion
              expanded={vqlExpanded}
              onChange={handleVqlAccordionChange}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="vql-content"
                id="vql-header"
                style={{ display: "flex", alignItems: "center", marginTop:'4%'}}
              >
                <Typography variant="h6" style={{ marginLeft: "8px" }}>
                  VQL Builder
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <TextField
                  fullWidth
                  multiline
                  rows={10}
                  variant="outlined"
                  value={vqlQuery}
                  onChange={(e) => setVqlQuery(e.target.value)}
                  InputProps={{
                    disableUnderline: true,
                    classes: {
                      root: theme.components.MuiOutlinedInput.styleOverrides.root,
                    },
                  }}
                  InputLabelProps={{
                    shrink: true,
                    style: {
                      color: theme.palette.primary.main,
                      fontWeight: "bold",
                    },
                  }}
                />
                {queryStatuses.map((queryStatus, index) => (
                  <Typography
                    key={index}
                    variant="body1"
                    style={{
                      marginTop: "8px",
                      color:
                        queryStatus.status === "success" ? "green" : "red",
                    }}
                  >
                    {queryStatus.query}: {queryStatus.status}
                  </Typography>
                ))}
              </AccordionDetails>
            </Accordion>

            <Accordion
              expanded={filtersExpanded}
              onChange={handleFiltersAccordionChange}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="filters-content"
                id="filters-header"
              >
                <Typography variant="h6">Filters</Typography>
              </AccordionSummary>
              <AccordionDetails style={{ maxHeight: 100, overflowY: "auto" }}>
                <Box display="flex" flexDirection="column">
                  {filters.map((filter, index) => (
                    <Box
                      key={index}
                      mb={2}
                      display="flex"
                      alignItems="center"
                      style={{ marginBottom: 16 }}
                    >
                      <TextField
                        select
                        label="Select Object"
                        name="object"
                        variant="outlined"
                        value={filter.object}
                        onChange={(event) => handleInputChange(index, event)}
                        style={{
                          marginRight: 8,
                          minWidth: 265,
                        }}
                        InputProps={{
                          classes: {
                            root: theme.components.MuiOutlinedInput.styleOverrides.root,
                          },
                        }}
                      >
                        {dummyData.objects.map((option) => (
                          <MenuItem
                            key={option.name}
                            value={option.name}
                          >
                            {option.name}
                          </MenuItem>
                        ))}
                      </TextField>
                      <TextField
                        select
                        label="Select Field"
                        name="field"
                        variant="outlined"
                        value={filter.field}
                        onChange={(event) => handleInputChange(index, event)}
                        style={{
                          marginRight: 8,
                          minWidth: 265,
                        }}
                        InputProps={{
                          classes: {
                            root: theme.components.MuiOutlinedInput.styleOverrides.root,
                          },
                        }}
                      >
                        {dummyData.fields.map((option) => (
                          <MenuItem
                            key={option}
                            value={option}
                          >
                            {option}
                          </MenuItem>
                        ))}
                      </TextField>
                      <TextField
                        select
                        label="Condition"
                        name="condition"
                        variant="outlined"
                        value={filter.condition}
                        onChange={(event) => handleInputChange(index, event)}
                        style={{
                          marginRight: 8,
                          minWidth: 265,
                        }}
                        InputProps={{
                          classes: {
                            root: theme.components.MuiOutlinedInput.styleOverrides.root,
                          },
                        }}
                      >
                        {dummyData.conditions.map((option) => (
                          <MenuItem
                            key={option}
                            value={option}
                          >
                            {option}
                          </MenuItem>
                        ))}
                      </TextField>
                      <TextField
                        label="Condition Value"
                        name="value"
                        variant="outlined"
                        value={filter.value}
                        onChange={(event) => handleInputChange(index, event)}
                        style={{
                          marginRight: 8,
                          minWidth: 265,
                        }}
                        InputProps={{
                          classes: {
                            root: theme.components.MuiOutlinedInput.styleOverrides.root,
                          },
                        }}
                      />
                      {filters.length > 1 && (
                        <IconButton
                          onClick={() => handleRemoveFilter(index)}
                          aria-label="remove filter"
                        >
                          <RemoveCircleOutlineIcon
                            color="error"
                          />
                        </IconButton>
                      )}
                      {index === filters.length - 1 && (
                        <IconButton
                          onClick={handleAddFilter}
                          aria-label="add filter"
                        >
                          <AddCircleOutlineIcon
                            color="primary"
                          />
                        </IconButton>
                      )}
                    </Box>
                  ))}
                </Box>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={compileQuery}
                  style={{ borderRadius: "9px", marginLeft: 993 }}
                >
                  Compile Query
                </Button>
              </AccordionDetails>
            </Accordion>
          </Box>
        </Box>
        <Box
          display="flex"
          justifyContent="flex-end"
          mt={2}
          mr={31}
        >
          <Button
            variant="contained"
            color="secondary"
            onClick={handleGenerateVql}
            disabled={generateVqlDisabled} // Disable the button after generating
            style={{ borderRadius: "9px" }}
          >
            Generate VQL
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleSaveQuery}
            style={{ borderRadius: "9px"}}
          >
            Save Query
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={handleNavigateNext}
            style={{ borderRadius: "9px"}}
          >
            Next
          </Button>
        </Box>
      </Box>
      <ToastContainer />
      </div>
    </div>
    </ThemeProvider>
  );
};

export default VQLBuilder;
