import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook
import '../assets/styles/TypeOfMigration.css'; // Adjust the path if necessary

// Import images
import image1 from '../assets/images/image1.png'; // Adjust the path if necessary
import image2 from '../assets/images/image2.png'; // Adjust the path if necessary
import hex from '../assets/svg/hex.svg'; // Adjust the path if necessary
import singlehex from '../assets/svg/singlehex.svg'; // Adjust the path if necessary
import centerSvg from '../assets/svg/center.svg'; // Adjust the path if necessary
import Header from './Header';

const TypeOfMigration = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  // Function to handle click on the singlehex SVG
  const handleHexClick = () => {
    navigate('/projects'); // Route to /projects
  };

  return (
    <div className="container">
      <div className="image1" style={{ backgroundImage: `url(${image1})` }}>
        <Header />
        <div className="text-overlay">
          <h1>Select the type of migration</h1>
          <p>Data migration / Document migration</p>
        </div>
      </div>
      
      <div className="image2" style={{ backgroundImage: `url(${image2})` }}>
        <img src={hex} alt="Hex" className="hex-svg" />

        <img 
          src={singlehex} 
          alt="Single Hex" 
          className="singlehex-svg" 
          onClick={handleHexClick} // Add click event handler here
        />
      
      </div>
    </div>
  );
};

export default TypeOfMigration;
