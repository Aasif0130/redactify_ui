import React, { useEffect, useState } from 'react';
import '../assets/styles/Scope.css'; // Adjust the path if necessary
import { scopeService } from '../ServiceManager/ScopeService';
import Header from './Header'; // Assuming you have a Header component

// Import images
import scope from '../assets/images/scope.png'; // Adjust the path if necessary
import image2 from '../assets/images/image2.png'; // Adjust the path if necessary

// Import SVG icons
import icon1 from '../assets/svg/icon1.svg'; // Adjust the path if necessary
import icon2 from '../assets/svg/icon4.svg'; // Adjust the path if necessary
import icon3 from '../assets/svg/icon2.svg'; // Adjust the path if necessary
import icon4 from '../assets/svg/icon5.svg'; // Adjust the path if necessary
import icon5 from '../assets/svg/icon3.svg'; // Adjust the path if necessary

import { toast, ToastContainer } from 'react-toastify'; // Import Toastify
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const icons = [icon1, icon2, icon3, icon4, icon5];

const Scope = () => {
  const [scopes, setScopes] = useState([]);
  const [checkedItems, setCheckedItems] = useState([]);
  const [saveClicked, setSaveClicked] = useState(false);
  const [projectId, setProjectId] = useState("");
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    const storedProjectId = localStorage.getItem('selectedProjectId') || "";
    const storedCheckedItems = JSON.parse(localStorage.getItem('checkedItems')) || [];

    setProjectId(storedProjectId);

    const fetchScopes = async () => {
      try {
        const response = await scopeService.fetchScopes();
        setScopes(response.data); // Assuming response.data contains the list of scopes
        const initialCheckedItems = new Array(response.data.length).fill(false);
        storedCheckedItems.forEach((checked, index) => {
          if (index < initialCheckedItems.length) {
            initialCheckedItems[index] = checked;
          }
        });
        setCheckedItems(initialCheckedItems);
      } catch (error) {
        console.error('Error fetching scopes:', error);
      }
    };

    fetchScopes();
  }, []);

  const handleCheckboxChange = (index) => {
    const updatedCheckedItems = checkedItems.map((item, i) => (i === index ? !item : item));
    setCheckedItems(updatedCheckedItems);
    localStorage.setItem('checkedItems', JSON.stringify(updatedCheckedItems)); // Save to local storage
  };

  const handleSave = async () => {
    setSaveClicked(true);
    const selectedScopeIds = scopes
      .filter((_, index) => checkedItems[index])
      .map(scope => scope.id);

    if (projectId) {
      const data = {
        projectId: projectId,
        projectScopeIds: selectedScopeIds
      };

      try {
        await scopeService.saveProjectScopes(data);
        const selectedScopeNames = scopes
          .filter((_, index) => checkedItems[index])
          .map(scope => scope.projectScopeName)
          .join(', ');

        toast.success(`Scope items selected: ${selectedScopeNames}`, {
          position: "top-center",
          autoClose: 3000,
          className: 'custom-toastify' // Apply custom class
        });
      } catch (error) {
        console.error('Error saving scope project:', error);
        toast.error('Failed to save scope project.', {
          position: "top-center",
          autoClose: 3000,
          className: 'custom-toastify' // Apply custom class
        });
      }
    } else {
      console.error('Project ID is not available');
    }
  };

  const handleNext = () => {
    navigate('/mapper');
  };

  return (
    <div className="scope-container">
      <div className="scope-scope" style={{ backgroundImage: `url(${scope})` }}>
        <Header />
        <div className="scope-text-overlay">
          <h1>Scope</h1>
          <p>Define the scope for migration</p>
        </div>
      </div>
      
      <div className="scope-image2" style={{ backgroundImage: `url(${image2})` }}>
        <div className="scope-items">
          {scopes.slice(0, 5).map((scope, index) => (
            <div key={scope.id} className="scope-item">
              <img src={icons[index]} alt="icon" className="scope-icon" />
              <span className="scope-name">{scope.projectScopeName}</span>
              <input
                id={`checkbox-${index}`}
                type="checkbox"
                className="scope-checkbox"
                checked={checkedItems[index] || false}
                onChange={() => handleCheckboxChange(index)}
              />
            </div>
          ))}
        </div>
        <div className="scope-buttons">
          <button className="scope-button" onClick={() => toast.info('Back button clicked')}>Back</button>
          <button className="scope-button" onClick={handleSave}>Save</button>
          <button className="scope-button" onClick={handleNext} disabled={!saveClicked}>Next</button>
        </div>
      </div>
      <ToastContainer className="custom-toastify" /> {/* Add ToastContainer with custom class */}
    </div>
  );
};

export default Scope;
