// scopeService.js

import { APIConfiguration } from "../ApiPath/Constant";
import axios from "axios";

export const scopeService = {
  fetchScopes: async function () {
    return axios.get(`${APIConfiguration.rootURL}/getAllScope`);
  },


  saveProjectScopes: async function (data) {
    try {
        const token = localStorage.getItem('token');
        console.log('Retrieved Token:', token);

        const config = APIConfiguration.getConfig(token);
        console.log('Request Config:', config);

        const response = await axios.post(`${APIConfiguration.rootURL}/insertProjectScope`, data, config);
        console.log('Response Data:', response.data);

        return response;
    } catch (error) {
        console.error('Error saving project scopes:', error);
        throw error; // Rethrow error if needed for further handling
    }
}




};


