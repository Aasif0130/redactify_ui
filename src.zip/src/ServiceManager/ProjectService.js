
import { APIConfiguration } from '../ApiPath/Constant';
import axios from 'axios';
export const ProjectService = {

  fetchProjectTypes: async function () {
    return axios.get(`${APIConfiguration.rootURL}/projecttype`);
  },

  fetchProjectUsers: async function () {
    return axios.get(`${APIConfiguration.rootURL}/getAllUsers`);
  },

  createProject: (projectData) => {
    return axios.post(`${APIConfiguration.rootURL}/createProject`, [projectData]);
  },

  fetchProjects: async () => {
    return  axios.get(`${APIConfiguration.rootURL}/getAllProject`);
  }


};