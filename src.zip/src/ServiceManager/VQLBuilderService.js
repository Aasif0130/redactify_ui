// scopeService.js

import { APIConfiguration } from "../ApiPath/Constant";
import axios from "axios";

export const vqlService = {

  insertDetails: async function (data) {
    return await axios.post(`${APIConfiguration.rootURL}/insertVqlDetails`, data);
  },

  processDetails: async function (data) {
    return await axios.post(`${APIConfiguration.rootURL}/processVqlDetails`, data);
  },

};


