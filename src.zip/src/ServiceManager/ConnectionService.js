
import {APIConfiguration} from '../ApiPath/Constant';
import axios from 'axios';
export const ConnectionService = {
  connectToSourceVault: async function(username, password) {
    if (!username || !password) {
      throw new Error('Username and password are required for source connection');
    }
    

    try {
      const response = await axios.post(`${APIConfiguration.rootURL}/sourceVaultConnect`, {
        username: username,
        password: password,
      });
      return response.data; // Assuming your API returns data
    } catch (error) {
      throw new Error(`Error connecting to source vault: ${error.message}`);
    }
  },

  connectToTargetVault: async function(username, password) {
    if (!username || !password) {
      throw new Error('Username, password, and projectId are required for target connection');
    }

    const projectId = localStorage.getItem('projectId');
    if (!projectId) {
      throw new Error('Project ID is missing from local storage');
    }

    try {
      const response = await axios.post(`${APIConfiguration.rootURL}/targetVaultConnect`, {
        username: username,
        password: password,
        projectId: projectId
      });
      return response.data; // Assuming your API returns data
    } catch (error) {
      throw new Error(`Error connecting to target vault: ${error.message}`);
    }
  },
};

const authRequest = {
  username: 'migratepro_prana@partnersi-prana4life.com',
  password: 'Rudhrainfo#5',
  version: 'v24.1'
};
export const extractConfig = () => {
  const token = localStorage.getItem('token');
  const config = APIConfiguration.getConfig(token);

  return axios.post(`${APIConfiguration.rootURL}/configreport`, authRequest, config);
};

export const insertSourceObject = (projectId) => {
  return axios.post(`${APIConfiguration.rootURL}/insertSourceObject`, {projectId} );
};

export const insertTargetObject = (projectId) => {
  return axios.post(`${APIConfiguration.rootURL}/insertTargetObject`,  {projectId} );
}