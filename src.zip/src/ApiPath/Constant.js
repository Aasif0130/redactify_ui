
export const APIConfiguration = {
    rootURL: 'http://localhost:8080',
    
    getConfig: function (token = null) {
      const headers = {
        'Content-Type': 'application/json',
      };
      
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
  
      return { headers };
    }
  };
  